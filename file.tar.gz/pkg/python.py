# Note - all of the imports used by any script will be need to
# be imported in this script.
exec(open("script.py").read(), globals())